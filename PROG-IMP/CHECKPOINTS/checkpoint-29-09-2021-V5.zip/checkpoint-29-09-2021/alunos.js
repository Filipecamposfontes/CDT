function Aluno(nome_, qFaltas_, notas_,) {
  this.nome = nome_;
  this.qFaltas = qFaltas_;
  this.notas = notas_;
  this.media = function(){
    let soma = 0;
    for (let i = 0; i < this.notas.length; i++){
        soma += this.notas[i]
    }
    const media = soma/this.notas.length;
    return media.toFixed(2);
}   

}


/* Gera lista de alunos aleatoriamente */
let alunos = [];
for (let i = 0; i <= 10; i++) {
  let nome = "aluno" + i;

  let qFaltas = function(){
    let addFalta = this.qFaltas + 1;
  }

  /* Gera array de notas aleatoriamente */
  let notas = [];
  for (let n = 0; n <= 5; n++) {
    let numeroAleatorio = Math.random() * 10;
    notasFix = Number(numeroAleatorio.toFixed(0));
    notas.push(notasFix);
  }

  
  const aluno = new Aluno(nome, qFaltas, notas,this.media);
  alunos.push(aluno);
}

module.exports = {
  Aluno,
  alunos,
};